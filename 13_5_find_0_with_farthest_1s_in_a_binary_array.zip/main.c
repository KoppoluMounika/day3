/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n;
    scanf("%d", &n);  

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);  
    }

    int maxDist = -1, index = -1;

    for (int i = 0; i < n; i++) {
        if (arr[i] == 0) {
            int leftDist = -1, rightDist = -1;
            
            
            for (int j = i; j >= 0; j--) {
                if (arr[j] == 1) {
                    leftDist = i - j;
                    break;
                }
            }
            
            
            for (int j = i; j < n; j++) {
                if (arr[j] == 1) {
                    rightDist = j - i;
                    break;
                }
            }

            int minDist = leftDist < rightDist ? leftDist : rightDist;
            
            if (minDist > maxDist) {
                maxDist = minDist;
                index = i;
            }
        }
    }

    printf("%d\n", index);

    return 0;
}
