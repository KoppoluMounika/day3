/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int rows; 
    scanf("%d",&rows);

    for (int i = 1; i <= rows; i++) {
        
        for (int j = i; j < rows; j++) {
            printf(" ");
        }

        
        for (int k = 1; k <= (2 * i - 1); k++) {
            if (k == 1 || k == (2 * i - 1) || i == rows) {
                printf("*");
            } else {
                printf(" ");
            }
        }

        printf("\n"); 
    }

    return 0;
}
