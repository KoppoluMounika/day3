/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char s[100];
    gets(s);
    int l=strlen(s);
    char s1[100];
    strcpy(s1,s);
    printf(s1);
    char temp;
    for(int i=0;i<l/2;i++){
        temp=s[i];
        s[i]=s[l-1-i];
        s[l-1-i]=temp;
    }
    if (strcmp(s1,s)==0){
        printf("it is pelendrome");
    }
    else{
        printf("it is not a palendrome");
    }

    return 0;
}
