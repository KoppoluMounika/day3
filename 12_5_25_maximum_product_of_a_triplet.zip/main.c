/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[100];
    int n;
    scanf("%d",&n);
    int temp;
    for (int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    for(int i=0;i<(n-1);i++){
        for(int j=i+1;j<n;j++){
            if(a[i]>a[j]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    int p1=a[n-1]*a[n-2]*a[n-3];
    int p2=a[0]*a[1]*a[n-1];
    if (p1>p2){
        printf("the maximum product of three numbers is %d",p1);
    }
    else{
        printf("the maximum product of three numbers is %d",p2);
    }

    return 0;
}
