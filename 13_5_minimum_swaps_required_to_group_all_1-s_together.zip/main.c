/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n;
    scanf("%d", &n); 
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]); 
    }

    int totalOnes = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] == 1) {
            totalOnes++;
        }
    }
    if (totalOnes <= 1) {
        printf("0\n");
        return 0;
    }

    int maxOnesInWindow = 0, currentOnes = 0;
    for (int i = 0; i < totalOnes; i++) {
        if (arr[i] == 1) {
            currentOnes++;
        }
    }
    maxOnesInWindow = currentOnes;

    for (int i = totalOnes; i < n; i++) {
        if (arr[i - totalOnes] == 1) currentOnes--;
        if (arr[i] == 1) currentOnes++;

        if (currentOnes > maxOnesInWindow)
            maxOnesInWindow = currentOnes;
    }

    int minSwaps = totalOnes - maxOnesInWindow;
    printf("%d\n", minSwaps);

    return 0;
}
