/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[100];
    int n;
    int current_count=0;
    int max_count=0;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    
    for(int i=0;i<n;i++){
        if(a[i]==1){
            current_count++;
            if(current_count>max_count){
                max_count=current_count;
            }
        }
        else{
            current_count=0;
        }
    }
    printf("the max consicutive ones is %d\n",max_count);
    int c=0;
    int m=0;
    for(int i=0;i<n;i++){
        if(a[i]==0){
            c++;
            if(c>m){
                m=c;
            }
        }
        else{
            c=0;
        }
    }
    printf("the max consicutive zeros is %d",m);

    return 0;
}
