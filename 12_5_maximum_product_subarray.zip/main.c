/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int maxProduct = arr[0];
    int minProduct = arr[0];
    int result = arr[0];
    
    for (int i = 1; i < n; i++) {
       
        if (arr[i] < 0) {
            int temp = maxProduct;
            maxProduct = minProduct;
            minProduct = temp;
        }

        if (arr[i] * maxProduct > arr[i]) {
            maxProduct = arr[i] * maxProduct;
        } else {
            maxProduct = arr[i];
        }

        if (arr[i] * minProduct < arr[i]) {
            minProduct = arr[i] * minProduct;
        } else {
            minProduct = arr[i];
        }
        if (maxProduct > result) {
            result = maxProduct;
        }
    }

    printf("%d", result);

    return 0;
}
