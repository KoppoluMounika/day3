/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100];
    
    int n,k;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&arr[i]);
    }
    scanf("%d",&k);

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    int min = arr[0] + k;
    int max = arr[n - 1] - k;
    
    if (min > max) {
        int temp = min;
        min = max;
        max = temp;
    }

    for (int i = 1; i < n - 1; i++) {
        int add = arr[i] + k;
        int sub = arr[i] - k;

        if (sub >= min || add <= max)
            continue;
        
        if (max - sub <= add - min)
            min = sub;
        else
            max = add;
    }

    int diff = max - min;

    printf("Minimum difference after modification: %d\n", diff);

    return 0;
}
