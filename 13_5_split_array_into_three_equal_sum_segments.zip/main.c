/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n;
    scanf("%d", &n);  

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);  
    }

    int totalSum = 0;
    for (int i = 0; i < n; i++) {
        totalSum += arr[i];
    }

    if (totalSum % 3 != 0) {
        printf("-1\n"); 
        return 0;
    }

    int partSum = totalSum / 3;
    int sum = 0;
    int firstCut = -1, secondCut = -1;

    for (int i = 0; i < n; i++) {
        sum += arr[i];

        if (sum == partSum && firstCut == -1) {
            firstCut = i;  
        } else if (sum == 2 * partSum && secondCut == -1) {
            secondCut = i;  
            break; 
        }
    }

    if (firstCut != -1 && secondCut != -1) {
        printf("[%d, %d]\n", firstCut, secondCut); 
    } else {
        printf("-1\n"); 
    }

    return 0;
}
