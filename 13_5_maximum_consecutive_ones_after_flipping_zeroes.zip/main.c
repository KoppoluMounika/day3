/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100],n,k;
    scanf("%d %d",&n,&k);
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    
    int res = 0;
    for (int i = 0; i < n; i++) {
        int cnt = 0; 

        for (int j = i; j < n; j++) {
            if (arr[j] == 0)
                cnt++;

            if (cnt <= k) {
                int len = j - i + 1;
                if (len > res)
                    res = len;
            }
        }
    }

    printf("%d\n", res);

    return 0;
}
