/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n, k;
    scanf("%d %d", &n, &k); 

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]); 
    }

    int count = 0;
    int product = 1;
    int left = 0;

    for (int i = 0; i < n; i++) {
        product *= arr[i];  

        
        while (left <= i && product >= k) {
            product /= arr[left];  
            left++;               
        }

        
        count += (i - left + 1);
    }

    printf("%d\n", count); 

    return 0;
}
