/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char s1[30]="mounika";
    char s2[30]="koppolu";
    int l1=strlen(s1);
    int l2=strlen(s2);
    for (int i=0;i<=l2;i++){
        s1[l1+i]=s2[i];
    }
    printf("%s",s1);

    return 0;
}
