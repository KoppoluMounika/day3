/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[100];
    int n;
    scanf("%d",&n);
    for (int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    int temp;
    for(int i=0;i<(n-i);i++){
        for(int j=i+1;j<n;j++){
            if(a[i]<a[j]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
                
            }
        }
    }
    for(int i=0;i<n;i++){
        if(a[i]!=a[0]){
            printf("the second largest element is %d\n",a[i]);
            break;
        }
    }
    

    return 0;
}