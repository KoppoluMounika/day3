/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[100];
    int n,count=1;
    scanf("%d",&n);
    for (int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    int temp;
    for(int i=0;i<(n-i);i++){
        for(int j=i+1;j<n;j++){
            if(a[i]<a[j]){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
                
            }
        }
    }
    for(int i=1;i<n;i++){
        if(a[i]!=a[i-1]){
            count+=1;
        }
        if(count==3){
        printf("the third largest number is%d",a[i]);
    }
    }
    
    

    return 0;
}