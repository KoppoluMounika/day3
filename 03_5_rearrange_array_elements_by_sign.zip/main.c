/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int arr[100], pos[100], neg[100];
    int n, p = 0, q = 0;

    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);

        if(arr[i] >= 0)
            pos[p++] = arr[i]; 
        else
            neg[q++] = arr[i];  
    }

    int i = 0, j = 0, k = 0;
    while(i < p && j < q) {
        arr[k++] = pos[i++];
        arr[k++] = neg[j++];
    }

    while(i < p) {
        arr[k++] = pos[i++];
    }

    while(j < q) {
        arr[k++] = neg[j++];
    }

    for(int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
