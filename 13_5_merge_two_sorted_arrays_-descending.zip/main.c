/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[100],b[100],c[200];
    int n;
    scanf("%d",&n);
    for (int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    
    for(int i=0;i<n;i++){
        scanf("%d",&b[i]);
    }
    for(int i=0;i<n;i++){
        c[i]=a[i];
    }
    for(int i=0;i<n;i++){
        c[n+i]=b[i];
    }
    int t=2*n;
    for (int i=0;i<t-1;i++){
        for(int j=0;j<(t-i)-1;j++){
            if(c[j]<c[j+1]){
                int temp=c[j];
                c[j]=c[j+1];
                c[j+1]=temp;
            }
        }
    }
    for (int i=0;i<t;i++){
        printf("%d",c[i]);
    }

    return 0;
}


