/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[100], n;
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int count1 = 0, count2 = 0;
    int candidate1 = -1, candidate2 = -1;

    for (int i = 0; i < n; i++) {
        if (arr[i] == candidate1) {
            count1++;
        } else if (arr[i] == candidate2) {
            count2++;
        } else if (count1 == 0) {
            candidate1 = arr[i];
            count1 = 1;
        } else if (count2 == 0) {
            candidate2 = arr[i];
            count2 = 1;
        } else {
            count1--;
            count2--;
        }
    }

    count1 = 0;
    count2 = 0;

    for (int i = 0; i < n; i++) {
        if (arr[i] == candidate1)
            count1++;
        else if (arr[i] == candidate2)
            count2++;
    }

    int found = 0;
    if (count1 > n / 3) {
        printf("Majority element > n/3: %d\n", candidate1);
        found = 1;
    }
    if (count2 > n / 3 && candidate2 != candidate1) {
        printf("Majority element > n/3: %d\n", candidate2);
        found = 1;
    }

    if (!found) {
        printf("No element appears more than n/3 times.\n");
    }

    return 0;
}
